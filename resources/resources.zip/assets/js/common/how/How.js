import React from 'react';
import how1 from './img/how1.png';
import how2 from './img/how2.png';
import how3 from './img/how3.png';
import how4 from './img/how4.png';
import './how.css';

class How extends React.Component {
    render(){
        return(
            <section className="how_it_works white_bg text-center mb-0 pt-70 pb-70 ">
			
				<div className="page-container-responsive page-container-no-padding">
					<div className="top_text_wrap">
						<div className="section-intro">
							<h2>How it works </h2>
						</div>
						<div className="how_it_sect col-lg-3 col-md-6 col-sm-12">
							<img src={how1} alt="Vacation Rentals"/>
							<h3>Search</h3>
							<p>Search for the perfect vacation home for rent from our verified listings</p>
						</div>
						<div className="how_it_sect col-lg-3 col-md-6 col-sm-12">
							<img src={how2} alt="Vacation Rentals"/>
							<h3>Make an inquiry</h3>
							<p>Contact the owner or property manager directly</p>
						</div>
						<div className="how_it_sect col-lg-3 col-md-6 col-sm-12">
							<img src={how3} alt="Vacation Rentals"/>
							<h3>Make the booking</h3>
							<p>Once you have settled on the home of your choice, book direct with the homeowner or property manager</p>
						</div>
						<div className="how_it_sect col-lg-3 col-md-6 col-sm-12">
							<img src={how4} alt="Vacation Rentals"/>
							<h3>Review your stay</h3>
							<p>Tell others about the great trip you had and place you stayed</p>
						</div>
					</div>
				</div>
			</section>
        )
    }
}

export default How;