import React from 'react'

class Help extends React.Component{
    render(){
        return(
            <div>dddd</div>
        )
    }
}

export default Help