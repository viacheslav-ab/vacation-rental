import React from 'react';
import './communicate.css';

class Communicate extends React.Component {
    render(){
        return(
            <section className="hg_section--relative py-0 ">
            <div className="full_width ">
              <div className="row">
                <div className="col-md-12 col-sm-12">
                  {/* media-container */}
                  <div className="media-container style2 hsize-400 d-flex align-items-start align-items-lg-center justify-content-center">
                    {/* bg source */}
                    <div className="kl-bg-source">
                      <div className="kl-bg-source__bgimage" style={{backgroundImage: 'url(https://www.vacation.rentals/images/vacation_2.jpg)', backgroundRepeat: 'no-repeat', backgroundAttachment: 'scroll', backgroundPositionX: 'center', backgroundPositionY: '75%', backgroundSize: 'cover'}} />
                      <div className="kl-bg-source__overlay" style={{backgroundColor: 'rgba(0,0,0,0.25)'}} />
                      <div className="kl-bg-source__overlay-gloss" />
                    </div>
                    {/*/ bg-source */}
                    {/* media-container button */}
                    <div className="media-container__link media-container__link--btn media-container__link--style-borderanim2 py-2 d-flex flex-column justify-content-center">
                      <div className="row">
                        <div className="borderanim2-svg text-center mx-auto">
                          <svg height={140} width={140} xmlns="http://www.w3.org/2000/svg">
                            <rect className="borderanim2-svg__shape" x={0} y={0} height={140} width={140} />
                          </svg>
                          <span className="media-container__text"><a href="javascript:void(0)" className="signup_popup_head2" title="Register"><img src="https://www.vacation.rentals/images/vr-icon-white.png" className="img-fluid media-container-icon" alt="Vacation Rentals" /> </a></span>
                        </div>
                      </div>
                      <div className="row">
                        <div className="col-10 col-md-12 float-none mx-auto">
                          <div className="text-center pt-1 pt-md-4">
                            <h2 className="tbk__title kl-font-alt fs-xs-xl fs-l fw-bold white shadow-text ">
                              Communicate directly with each other <span className="tcolor-ext">BEFORE</span> the reservation is made.
                            </h2>
                            <p className="white mt-2">
                              <span className="d-block fs-xs-md fs-22">We think of ourselves as "The Vacation Matchmaker!"</span>
                              <span className="d-block mt-1 fs-xs-small fs-18">We just make the introductions and leave the rest to you - the homeowner and  traveler.</span>
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                    {/*/ media-container button */}
                  </div>
                  {/*/ media-container */}
                </div>
                {/*/ col-md-12 col-sm-12  */}
              </div>
              {/*/ row */}
            </div>
            {/* Bottom mask style 3 */}
            <div className=" kl-bottommask kl-bottommask--mask3">
              {/* <svg width="5000px" height="57px" className="svgmask svgmask-left " viewBox="0 0 5000 57" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                <defs>
                  <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-mask3">
                    <feOffset dx={0} dy={3} in="SourceAlpha" result="shadowOffsetInner1" />
                    <feGaussianBlur stdDeviation={2} in="shadowOffsetInner1" result="shadowBlurInner1" />
                    <feComposite in="shadowBlurInner1" in2="SourceAlpha" operator="arithmetic" k2={-1} k3={1} result="shadowInnerInner1" />
                    <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.4 0" in="shadowInnerInner1" type="matrix" result="shadowMatrixInner1" />
                    <feMerge>
                      <feMergeNode in="SourceGraphic" />
                      <feMergeNode in="shadowMatrixInner1" />
                    </feMerge>
                  </filter>
                </defs>
                <path d="M9.09383679e-13,57.0005249 L9.09383679e-13,34.0075249 L2418,34.0075249 L2434,34.0075249 C2434,34.0075249 2441.89,33.2585249 2448,31.0245249 C2454.11,28.7905249 2479,11.0005249 2479,11.0005249 L2492,2.00052487 C2492,2.00052487 2495.121,-0.0374751261 2500,0.000524873861 C2505.267,-0.0294751261 2508,2.00052487 2508,2.00052487 L2521,11.0005249 C2521,11.0005249 2545.89,28.7905249 2552,31.0245249 C2558.11,33.2585249 2566,34.0075249 2566,34.0075249 L2582,34.0075249 L5000,34.0075249 L5000,57.0005249 L2500,57.0005249 L1148,57.0005249 L9.09383679e-13,57.0005249 Z" className="bmask-bgfill" filter="url(#filter-mask3)" fill="#fbfbfb" />
              </svg> */}
              <i className="glyphicon glyphicon-chevron-down" />
            </div>
            {/*/ Bottom mask style 3 */}
          </section>
        );
    }
}

export default Communicate;
