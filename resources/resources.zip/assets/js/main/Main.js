// standard library
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter as Router, Route, Switch  } from 'react-router-dom';
// common components
import Header from '../common/header/Header';
import Banner from '../common/banner/Banner';
import How from '../common/how/How';
import Popular from '../common/popular/Popular';
import Hostsection from '../common/host/Hostsection';
import Communicate from '../common/communicate/Communicate';
import Listing from '../listing/Listing';


// total css
import './all.css';
import './main.css';
import './header.css';
import './element.css';
import './form.css';
import './ptjs.css';
import './margin.css';
import './common.css';
import './animate.css';
import Footer from '../common/footer/Footer';




/////////////////Pages//////////////////////
import Home from '../pages/Home/Home'
import Login from '../pages/Login/Login'
import Help from '../pages/Help/Help'

export default class Main extends Component {
    render() {
        return (
          <Router basename="/">
            <Switch> 
              <Route exact path='/' component = {Home}/>
              <Route path='/login' component = {Login}/>
              <Route path='/help' component = {Help}/>
            </Switch> 
          </Router>
        )
    }
}

if (document.getElementById('root')) {
    ReactDOM.render(<Main />, document.getElementById('root'));
}
