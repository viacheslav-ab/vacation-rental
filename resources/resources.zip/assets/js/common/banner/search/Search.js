import React from 'react';

class Search extends React.Component {
    render(){
        return(
            <form>
                <h1>ok</h1>
            </form>
        );
    }
}

export default Search;