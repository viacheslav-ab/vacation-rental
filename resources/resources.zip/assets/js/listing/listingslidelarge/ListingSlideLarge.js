import React from 'react';

class ListingSlideLarge extends React.Component {
    render(){
        return(
            <div className="featured-swipe swiper-container hsize-400 swiper-container-horizontal">
            {/* Additional required wrapper */}
            <div className="swiper-wrapper" style={{transform: 'translate3d(0px, 0px, 0px)'}}>
              {/* Slides */}
              <div className="swiper-slide swiper-slide-active" data-tag={1} style={{width: 751}}>
                {/* Big post */}
                <div className="post big-post max-h-400 ">
                  {/* Post link wrapper */}
                  <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder" title="Cape Coral, Florida Vacation Rentals">
                    {/* Border wrapper */}
                    <span className="hoverBorderWrapper">
                      {/* Image */}
                      <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__1440x960.jpg" className="img-fluid img-cover" alt="Cape Coral, Florida Vacation Rentals" title="Cape Coral, Florida Vacation Rentals" />
                      {/*/ Image */}
                      {/* Hover border/shadow */}
                      <span className="theHoverBorder" />
                      {/*/ Hover border/shadow */}
                    </span>
                    {/*/ Border wrapper */}
                  </a>
                  {/*/ Post link wrapper */}
                  {/* Post details */}
                  <div className="post-details">
                    {/* Title with link */}
                    <h3 className="m_title">
                      <a href="https://www.vacation.rentals/rooms/11449" title="Cape Coral, Florida Vacation Rentals">
                        Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee
                      </a>
                    </h3>
                    {/*/ Title with link */}
                    {/* Details & tags */}
                    <em>
                      3 Bedroom  House in Cape Coral Florida
                    </em>
                    {/*/ Details & tags */}
                  </div>
                  {/*/ Post details */}
                </div>
                {/*/ Big post */}
              </div>
              {/*/ Slides */}
            </div>
            <span className="swiper-notification" aria-live="assertive" aria-atomic="true" /></div>
        );
    }
}

export default ListingSlideLarge;