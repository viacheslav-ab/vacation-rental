// standard library
import React, { Component } from 'react';
import ReactDOM from 'react-dom';
// common components

import Header from '../../common/header/Header';
import Banner from '../../common/banner/Banner';
import How from '../../common/how/How';
import Popular from '../../common/popular/Popular';
import Hostsection from '../../common/host/Hostsection';
import Communicate from '../../common/communicate/Communicate';
import Listing from '../../listing/Listing';


// total css









import Footer from '../../common/footer/Footer';

export class Home extends Component {
    render() {
        return (
            <div className="body">
                <Header/>
                <main id="site-content" role="main">
                <div className="hero shift-with-hiw js-hero">
                <Banner/>
                <How/>
                <Communicate/>
                   
                <Listing/>
                <Popular/>

                      <div className="action_box style1 mb-80" data-arrowpos="center">
        <div className="action_box_inner container ">
          <div className="page-container-no-padding action_box_content row d-flex-lg align-content-center">
            {/* Content */}
            <div className="ac-content-text col-sm-12 col-md-12 col-lg-9 mb-md-20">
              {/* Title */}
              <h4 className="text text-center text-md-left ">
                Ready to join the hundreds of homeowners and property managers listing on <span className="fw-bold">Vacation.Rentals?</span>
              </h4>
            </div>
            {/*/ Content col-sm-12 col-md-12 col-lg-7 mb-md-20 */}
            {/* Call to Action buttons */}
            <div className="ac-buttons col-sm-12 col-md-12 col-lg-3 d-flex align-self-center justify-content-center justify-content-lg-end">
              <a href="https://www.vacation.rentals/rooms/new" className="btn-lined btn-lg ac-btn w-100 text-center" title="List your property with Vacation.Rentals">
                Get Started!
              </a>
            </div>
            {/*/ Call to Action buttons */}
          </div>
          {/*/ .action_box_content */}
        </div>
        {/*/ .action_box_inner */}
      </div>
                <Hostsection/>
                <Footer/>
                </div>
                </main>
            </div>
        )
    }
}

export default Home;
