import React from 'react';
import ReactDOM from 'react-dom';
import OwlCarousel from 'react-owl-carousel';
import 'owl.carousel/dist/assets/owl.carousel.css';
import 'owl.carousel/dist/assets/owl.theme.default.css';
class ListingSlideSmall extends React.Component {
    render(){
        return(

          <OwlCarousel
          className="owl-theme"
          loop
          margin={10}
          items = {4}
          loop = {true}
          autoHeightClass 
          nav
          >
          <div className="swiper-slide tag-id-1" >
            <div className="post hsize-150">
              <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder">
                <span className="hoverBorderWrapper">
                  <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__450x250.jpg" className="img-fluid img-cover h-100" alt="unique" title="Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee" />
                  <span className="theHoverBorder" />
                </span>
              </a>
              <div className="post-details pb-1 bg-black-trans-50">
                <h6 className="m_title">
                <a href = '#' title="3 Bedroom  House in Cape Coral Florida">
                    Link Bedroom  House in Cape Coral Florida
                  </a>
                </h6>
              </div>
            </div>
          </div>
          <div className="swiper-slide tag-id-1" >
            <div className="post hsize-150">
              <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder">
                <span className="hoverBorderWrapper">
                  <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__450x250.jpg" className="img-fluid img-cover h-100" alt="unique" title="Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee" />
                  <span className="theHoverBorder" />
                </span>
              </a>
              <div className="post-details pb-1 bg-black-trans-50">
                <h6 className="m_title">
                <a href = '#' title="3 Bedroom  House in Cape Coral Florida">
                    Link Bedroom  House in Cape Coral Florida
                  </a>
                </h6>
              </div>
            </div>
          </div>
          <div className="swiper-slide tag-id-1" >
            <div className="post hsize-150">
              <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder">
                <span className="hoverBorderWrapper">
                  <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__450x250.jpg" className="img-fluid img-cover h-100" alt="unique" title="Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee" />
                  <span className="theHoverBorder" />
                </span>
              </a>
              <div className="post-details pb-1 bg-black-trans-50">
                <h6 className="m_title">
                <a href = '#' title="3 Bedroom  House in Cape Coral Florida">
                    Link Bedroom  House in Cape Coral Florida
                  </a>
                </h6>
              </div>
            </div>
          </div>
          <div className="swiper-slide tag-id-1" >
            <div className="post hsize-150">
              <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder">
                <span className="hoverBorderWrapper">
                  <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__450x250.jpg" className="img-fluid img-cover h-100" alt="unique" title="Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee" />
                  <span className="theHoverBorder" />
                </span>
              </a>
              <div className="post-details pb-1 bg-black-trans-50">
                <h6 className="m_title">
                <a href = '#' title="3 Bedroom  House in Cape Coral Florida">
                    Link Bedroom  House in Cape Coral Florida
                  </a>
                </h6>
              </div>
            </div>
          </div>
          <div className="swiper-slide tag-id-1" >
            <div className="post hsize-150">
              <a href="https://www.vacation.rentals/rooms/11449" className="hoverBorder">
                <span className="hoverBorderWrapper">
                  <img src="https://www.vacation.rentals/images/rooms/11449/1537696269_7980__450x250.jpg" className="img-fluid img-cover h-100" alt="unique" title="Beautifully furnished villa  western exposure  3 bed  3 bath  hot tub  boat fee" />
                  <span className="theHoverBorder" />
                </span>
              </a>
              <div className="post-details pb-1 bg-black-trans-50">
                <h6 className="m_title">
                <a href = '#' title="3 Bedroom  House in Cape Coral Florida">
                    Link Bedroom  House in Cape Coral Florida
                  </a>
                </h6>
              </div>
            </div>
          </div>
          </OwlCarousel>
        );
    }
}

export default ListingSlideSmall;