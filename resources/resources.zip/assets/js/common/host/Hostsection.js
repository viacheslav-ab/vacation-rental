import React from 'react'
class Hostsection extends React.Component{

render(){
      return (
  
        <section className="host-section">
        <div className="page-container-responsive page-container-no-padding">
          <div className="row flex-container">
            <div className="col-md-4">
              <a href="https://www.vacation.rentals/about-us/no-fees-for-travelers-for-any-property-we-list">
                <div className="host-area cenralize">
                  <div className="host-container h-260">
                    <img className="h-100" title="Rent Direct From Owners With No Fees" alt="Rent Direct From Owners With No Fees" src="https://www.vacation.rentals/images/booking_1.jpg" />
                    <div className="image-shadow" />
                  </div>
                  <h4 className="stat-text">Deal direct with your host</h4>
                  <ul className="host-list">
                    <li>Open, unfiltered communication</li>
                    <li>Phone - email - even Live Chat</li>
                    <li>Build trust before you book</li>
                  </ul>
                </div>
              </a>
            </div>
            <div className="col-md-4">
              <a href="https://www.vacation.rentals/about-us/why-host">
                <div className="host-area cenralize">
                  <div className="host-container h-260">
                    <img className="h-100" title="Generate more reservations and bookings for your vacation rental property" alt="Generate more reservations and bookings for your vacation rental property" src="https://www.vacation.rentals/images/booking_2.jpeg" />
                    <div className="image-shadow" />
                  </div>
                  <h4 className="stat-text">Why list your home with us?</h4>
                  <ul className="host-list">
                    <li>Advertising and exposure</li>
                    <li>A simple annual membership and nothing more</li>
                    <li>Reach more prospective clients</li>
                  </ul>
                </div>
              </a>
            </div>
            <div className="col-md-4">
              <a href="https://www.vacation.rentals/rooms/new" className="login_popup_open">
                <div className="host-area cenralize">
                  <div className="host-container h-260">
                    <img className="img-responsive" title="Registering on www.vacation.rentals is fast and easy." alt="Registering on www.vacation.rentals is fast and easy." src="https://www.vacation.rentals/images/list-vacation1.jpg" />
                    <div className="image-shadow" />
                  </div>
                  <h4 className="stat-text">List your vacation rental</h4>
                  <ul className="host-list">
                    <li>It only takes minutes</li>
                    <li>Easy calendar, rates, and gallery</li>
                    <li>Immediate exposure</li>
                  </ul>
                </div>
              </a>
            </div>
          </div>
        </div>
      </section>

      );
    }
  };

  export default Hostsection;