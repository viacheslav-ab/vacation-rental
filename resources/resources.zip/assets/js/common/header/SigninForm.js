import React from 'react'

class SigninForm extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        if(this.props.visible == true) 
        return(
            <div className="panel top-home">
        <div className="panel-body bor-none  ">
          <a href="https://www.facebook.com/v2.12/dialog/oauth?client_id=426710514434903&state=ef798e5a3f2dbd62884f08187f7b6391&response_type=code&sdk=php-sdk-5.6.3&redirect_uri=https%3A%2F%2Fwww.vacation.rentals%2FfacebookAuthenticate&scope=public_profile%2Cemail%2Cuser_friends" className="fb-button fb-blue btn icon-btn btn-block btn-large row-space-1 btn-facebook font-normal pad-top">
            <span><i className="icon icon-facebook" /></span>
            <span>Log in with Facebook</span>
          </a>
          <a href="https://www.vacation.rentals/googleLogin" className="btn icon-btn btn-block btn-large row-space-1 btn-google font-normal pad-top mr1">
            <span><i className="icon icon-google-plus" /></span>
            <span>Log in with Google</span>
          </a>
          <a href="https://www.vacation.rentals/auth/linkedin" className="li-button li-blue btn icon-btn btn-block btn-large row-space-1 btn-linkedin mr1">
            <span><i className="icon icon-linkedin" /></span>
            <span>Log in with LinkedIn</span>
          </a>
          <div className="signup-or-separator">
            <span className="h6 signup-or-separator--text">or</span>  <hr />
          </div>
          <div className="clearfix" />
          <form method="POST" action="https://www.vacation.rentals/authenticate" acceptCharset="UTF-8" className="vr_form signup-form login-form ng-pristine ng-valid" id="login_form_modal" data-action="Signin" noValidate="novalidate">
            <input name="_token" id="token_modal" type="hidden" className="tooltipstered" />
            <input id="login_from_modal" name="from" type="hidden" defaultValue="email_login" className="tooltipstered" />
            <div className="control-group row-space-2 field_ico">
              <div className="pos_rel">
                <i className="icon-envelope" />
                <input className="decorative-input inspectletIgnore name-icon signin_email tooltipstered" placeholder="Email address" id="signin_email_modal" name="email" type="email" defaultValue />
              </div>
            </div>
            <div className="control-group row-space-3 field_ico">
              <div className="pos_rel">
                <i className="icon-lock" />
                <input className="decorative-input inspectletIgnore name-icon signin_password tooltipstered" placeholder="Password" id="signin_password_modal" data-hook="signin_password" name="password" type="password" defaultValue />
              </div>
            </div>
            <div className="clearfix row-space-3">
              <label htmlFor="remember_me2" className="checkbox remember-me">
                <input id="remember_me2_modal" className="remember_me" name="remember_me" type="checkbox" defaultValue={1} /> Remember me
              </label>
              <a href="javascript:void(0);" className="forgot-password forgot-password-popup link_color pull-right h5">Forgot password?</a>
            </div>
            <input className="btn btn-primary btn-block btn-large pad-top btn_new user-login-btn tooltipstered" id="user-login-btn_modal" type="submit" defaultValue="Log In" />
          </form>
        </div>
      </div>
        )
        else
        return(
            <div></div>
        )
    }
}

export default SigninForm