import React from 'react';
import ListingTitle from '../listing/listingtitle/Listingtitle';
import ListingSlideLarge from '../listing/listingslidelarge/ListingSlideLarge';
import ListingSlideSmall from '../listing/listingslidesmall/ListingSlideSmall';
import CitiesSlider from '../components/swipeslider/CitiesSlider'
class Listing extends React.Component {
    
    render(){
        const slides = [
            {
              city: 'Paris',
              country: 'France',
              img: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/paris.jpg',
            },
            {
              city: 'Singapore',
              img: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/singapore.jpg',
            },
            {
              city: 'Prague',
              country: 'Czech Republic',
              img: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/prague.jpg',
            },
            {
              city: 'Amsterdam',
              country: 'Netherlands',
              img: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/amsterdam.jpg',
            },
            {
              city: 'Moscow',
              country: 'Russia',
              img: 'https://s3-us-west-2.amazonaws.com/s.cdpn.io/142996/moscow.jpg',
            },
          ];
        
        return(
            <section className="discovery-section white_bg hg_section pt-60 pb-100" id="discover-recommendations">
                <div className="page-container-responsive page-container-no-padding">
                    <div className="container">
                        <div className="row">
                            <div className="col-sm-12 col-md-12">


                                <div className="latest_posts default-style kl-style-2">
                                    <div className="row gutter-sm">
                                        
                                        <div className="col-sm-12 col-md-4 col-lg-4">
                                            <div className="tag-swipe swiper-container hsize-400">
                                                 <CitiesSlider slides={slides}/>
                                            </div>
                                        
                                        </div>
                                        
                                        <div className="col-sm-12 col-md-8 col-lg-8">
                                                <ListingSlideLarge/>
                                        </div>
                                        <div className="col-sm-12 col-md-12 col-lg-12 mt-5">
                                            <div className="listing-swipe swiper-container hsize-150">
                                                <div className="swiper-wrapper">
                                                    {/* listing slide small */}
                                                    <ListingSlideSmall/>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        );
    }
}

export default Listing;