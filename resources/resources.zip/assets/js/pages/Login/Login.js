import React from 'react'
import Footer from '../../common/footer/Footer';
import Header from '../../common/header/Header';
class Login extends React.Component{

    constructor(props){
        super(props)

    }
    render(){
        return(

            <div className="body">
            <Header/>
            <main id="site-content" role="main">
        <div className="page-container-responsive page-container-auth margintop" style={{marginTop: 40, marginBottom: 40}}>
          <div className="row">
            <div className="log_pop col-center">
              <div className="panel top-home">
                <div className="panel-body pad-25 bor-none padd1 ">
                  <a href="https://www.facebook.com/v2.12/dialog/oauth?client_id=426710514434903&state=45edd518524aa40d7529ff5a22f4cb3d&response_type=code&sdk=php-sdk-5.6.3&redirect_uri=https%3A%2F%2Fwww.vacation.rentals%2FfacebookAuthenticate&scope=public_profile%2Cemail%2Cuser_friends" className="fb-button fb-blue btn icon-btn btn-block btn-large row-space-1 btn-facebook font-normal pad-top">
                    <span><i className="icon icon-facebook" /></span>
                    <span>Log in with Facebook</span>
                  </a>
                  <a href="https://www.vacation.rentals/googleLogin" className="btn icon-btn btn-block btn-large row-space-1 btn-google font-normal pad-top mr1">
                    <span><i className="icon icon-google-plus" /></span>
                    <span>Log in with Google</span>
                  </a>
                  <a href="https://www.vacation.rentals/auth/linkedin" className="li-button li-blue btn icon-btn btn-block btn-large row-space-1 btn-linkedin mr1">
                    <span><i className="icon icon-linkedin" /></span>
                    <span>Log in with LinkedIn</span>
                  </a>
                  <div className="signup-or-separator">
                    <span className="h6 signup-or-separator--text">or</span>  <hr />
                  </div>
                  <div className="clearfix" />
                  <form method="POST" action="https://www.vacation.rentals/authenticate" acceptCharset="UTF-8" className="vr_form signup-form login-form ng-pristine ng-valid" id="login_form" data-action="Signin" noValidate="novalidate">
                    <input name="_token" id="token" type="hidden" className="tooltipstered" />
                    <input id="login_from" name="from" type="hidden" defaultValue="email_login" className="tooltipstered" />
                    <div className="control-group row-space-2 field_ico">
                      <div className="pos_rel">
                        <i className="icon-envelope" />
                        <input className="decorative-input inspectletIgnore name-icon signin_email tooltipstered valid" placeholder="Email address" id="signin_email" name="email" type="email" defaultValue aria-invalid="false" />
                      </div>
                    </div>
                    <div className="control-group row-space-3 field_ico">
                      <div className="pos_rel">
                        <i className="icon-lock" />
                        <input className="decorative-input inspectletIgnore name-icon signin_password tooltipstered valid" placeholder="Password" id="signin_password" data-hook="signin_password" name="password" type="password" defaultValue aria-invalid="false" />
                      </div>
                    </div>
                    <div className="clearfix row-space-3">
                      <label htmlFor="remember_me2" className="checkbox remember-me">
                        <input id="remember_me2" className="remember_me" name="remember_me" type="checkbox" defaultValue={1} /> Remember me
                      </label>
                      <a href="javascript:void(0);" className="forgot-password forgot-password-popup link_color pull-right h5">Forgot password?</a>
                    </div>
                    <input className="btn btn-primary btn-block btn-large pad-top btn_new user-login-btn tooltipstered" id="user-login-btn" type="submit" defaultValue="Log In" />
                  </form>
                  <div className="panel-body bottom-panel1 text-center">  <hr />
                    Don’t have an account?
                    <a href="javascript:void(0);" className="link-to-signup-in-login login-btn link_color signup_popup_head">
                      Sign Up </a>
                  </div>                      </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      <Footer/>
      </div>
        )

    }
}

export default Login