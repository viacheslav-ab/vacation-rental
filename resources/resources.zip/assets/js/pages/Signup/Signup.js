import React from 'react'

class Signup extends React.Component{
    render(){
        return(
            <div></div>
        )
    }
}

export default Signup