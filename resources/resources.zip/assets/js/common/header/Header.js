import React from 'react';
import { BrowserRouter as Router, Route ,Link} from 'react-router-dom';
import Modal from 'react-bootstrap4-modal';

import logo from './logo.png';
import './header.css';
import SignupForm  from './SignupForm'
import SigninForm from './SigninForm';
class Navigation extends React.Component {
    constructor(props){
        super(props)
        this.state = {
            signup_visible : false,
            is_signup_form : true
        }
        this.signupmodalShowHandler = this.signupmodalShowHandler.bind(this)
        this.handlesingin_form = this.handlesingin_form.bind(this)
    }
    signupmodalShowHandler(e){
        console.log("Hello, K");
        this.setState({
            signup_visible : !this.state.signup_visible
        })
    }
    handlesingin_form(){
        this.setState({
            is_signup_form : !this.state.is_signup_form
        }) 
    }
    render(){
        let is_signup_form = this.state.is_signup_form;
        let is_singin_form = !is_signup_form;
        let modal_footer_text = <div className=" text-center">
            <hr />
            Already an Vacation.Rentals----- member?
            <a href="javascript:;" className="modal-link link-to-login-in-signup login-btn login_popup_head link_color" onClick={this.handlesingin_form}>
            Log In
            </a>
        </div>   
        let modal_label = 'Sign Up'  
        if(is_singin_form){
            modal_footer_text =  <div className=" text-center">  <hr />
            Don’t have an account?
            <a href="javascript:void(0);" className="link-to-signup-in-login login-btn link_color signup_popup_head" onClick={this.handlesingin_form}>
              Sign Up </a>
          </div>

          modal_label = 'Sign In'
        }
        return(
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <Link className="navbar-brand" to="/"><img className="logo" src={logo} alt="logo"/></Link>
                <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span className="navbar-toggler-icon"></span>
                </button>

                <div className="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul className="navbar-nav ml-auto">
                        <li className="nav-item ">
                            <Link className="nav-link menuitems" to="/login">Log In <span className="sr-only">(current)</span></Link>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link menuitems" href="javascript:;" onClick={this.signupmodalShowHandler}>Sign Up</a>
                        </li>
                        <li className="nav-item ">
                            <a className="nav-link menuitems" href="#">Help <span className="sr-only">(current)</span></a>
                        </li>
                        <li className="nav-item">
                            <a className="nav-link menuitems" href="#">Contact Us</a>
                        </li>
                        <li className="nav-item listitem">
                            <a className="nav-link listmenuitems" href="#">List your Home<span className="sr-only">(current)</span></a>
                        </li>
                    </ul>
                    
                </div>
                <Modal visible={this.state.signup_visible} onClickBackdrop={this.modalBackdropClicked}>
                    <div className="modal-header">

                    <h5 className="modal-title">{modal_label}</h5>
                    
                    <button type="button" className="close" data-dismiss="modal" aria-label="Close"  onClick={this.signupmodalShowHandler}>
                        <span aria-hidden="true">×</span>
                    </button>
                    </div>
                    <div className="modal-body">
                        <SignupForm visible={is_signup_form}/>
                        <SigninForm visible={is_singin_form}/>
                    </div>
                    <div className="modal-footer">
                    {modal_footer_text}
                    </div>
                </Modal>
            </nav>
        );
    }
}

export default Navigation;