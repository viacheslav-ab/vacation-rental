import React from 'react';
import './banner.css';

class Bannner extends React.Component{
    constructor(props){
        super(props)
        this.state = {
            width : 0,
            height : 0
        }
    }
    updateDimensions() {
        this.setState({width: $(window).width(), height: $(window).height()});
    }
    componentWillMount() {
        this.updateDimensions();
    }
    componentDidMount() {
        window.addEventListener("resize", this.updateDimensions);
    }
    componentWillUnmount() {
        window.removeEventListener("resize", this.updateDimensions);
    }


    render(){
        return(
            
      <div className="hero shift-with-hiw js-hero">
      <div className="hero__background" data-native-currency="ZAR" aria-hidden="true">
        <ul className="rslides" id="home_slider">
          <li className="slider-image"><img alt src="https://www.vacation.rentals/images/slider/slider_1538410411.jpeg" width="100%" /></li>
        </ul>
      </div>
      <div className="hero__content page-container page-container-full text-center" style={{padding: '0px !important'}}>
        <div className="va-container va-container-v va-container-h">
          <div className="rjbanercont">
            <h3>
              <span className="left_cls white">Vacation Rentals From Owners And Property Managers</span>
              <div className="hero-sub-text mt-15 white shadow-text d-flex justify-content-center">
                <div className="text-container">
                  <div className="animated fadeIn mr-20 d-inline-block delay-4s slower">No Fees.</div>
                  <div className="animated zoomIn slower d-inline-block">No Commissions.</div>
                  <div className="animated fadeIn ml-20 d-inline-block delay-4s slower">100% Verified.</div>
                </div>
              </div>
            </h3>
          </div>
          <div className="va-middle">
            <div className="back-black">
              <div className="show-sm hide-md sm-search">
                <form id="simple-search" className="simple-search hide js-p1-simple-search">
                  <div className="alert alert-with-icon alert-error  hide space-2 js-search-error"><i className="icon alert-icon icon-alert-alt" />
                    Please set location
                  </div>
                  <label htmlFor="simple-search-location" className="screen-reader-only">
                    Where do you want to go?
                  </label>
                  <input type="text" placeholder="Where do you want to go?" autoComplete="off" name="locations" id="simple-search-location" className="input-large js-search-location" />
                  <div className="row row-condensed space-top-2 space-2">
                    <div className="col-sm-6">
                      <label htmlFor="simple-search-checkin" className="screen-reader-only">
                        Check In
                      </label>
                      <input id="simple-search-checkin" type="text" name="checkin" className="input-large checkin js-search-checkin" placeholder="Check In" />
                    </div>
                    <div className="col-sm-6">
                      <label htmlFor="simple-search-checkout" className="screen-reader-only">
                        Check Out
                      </label>
                      <input id="simple-search-checkout" type="text" name="checkout" className="input-large checkout js-search-checkout" placeholder=" Check Out" />
                    </div>
                  </div>
                  <div className="select select-block space-2">
                    <label htmlFor="simple-search-guests" className="screen-reader-only">
                      Number of guests
                    </label>
                    <select id="simple-search-guests" name="guests" className="js-search-guests">
                      <option value={1}> 1 Guest </option>
                      <option value={2}> 2 Guests </option>
                      <option value={3}> 3 Guests </option>
                      <option value={4}> 4 Guests </option>
                      <option value={5}> 5 Guests </option>
                      <option value={6}> 6 Guests </option>
                      <option value={7}> 7 Guests </option>
                      <option value={8}> 8 Guests </option>
                      <option value={9}> 9 Guests </option>
                      <option value={10}> 10 Guests </option>
                      <option value={11}> 11 Guests </option>
                      <option value={12}> 12 Guests </option>
                      <option value={13}> 13 Guests </option>
                      <option value={14}> 14 Guests </option>
                      <option value={15}> 15 Guests </option>
                      <option value={16}> 16 Guests </option>
                      <option value={17}> 17 Guests </option>
                      <option value={18}> 18 Guests </option>
                      <option value={19}> 19 Guests </option>
                      <option value={20}> 20 Guests </option>
                      <option value={21}> 21 Guests </option>
                      <option value={22}> 22 Guests </option>
                      <option value={23}> 23 Guests </option>
                      <option value={24}> 24 Guests </option>
                      <option value={25}> 25 Guests </option>
                      <option value={26}> 26 Guests </option>
                      <option value={27}> 27 Guests </option>
                      <option value={28}> 28 Guests </option>
                      <option value={29}> 29 Guests </option>
                      <option value={30}> 30+ Guests </option>
                    </select>
                  </div>
                  <button type="submit" className="btn btn-primary btn-large btn-block">
                    messages.home.no_of_guest
                  </button>
                </form>
                <div className="input-addon js-p1-search-cta" id="sm-search-field">
                  <span className="input-stem input-large fake-search-field">
                    Where do you want to go?
                  </span>
                  <i className="input-suffix btn btn-primary icon icon-full icon-search" />
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="hero__content-footer hide-sm d-md-flex justify-content-center">
          <div className="col-sm-8">
            <div id="searchbar">
              <div className="searchbar rjsearchbar" data-reactid=".1">
                <form  className="simple-search clearfix" method="get" id="searchbar-form" name="simple-search">
                  <div className="saved-search-wrapper searchbar__input-wrapper">
                    <label className="input-placeholder-group searchbar__location">
                      <span className="input-placeholder-label screen-reader-only">Where do you want to go?</span>
                      <input className="menu-autocomplete-input text-truncate form-inline location input-large input-contrast" placeholder="Where do you want to go?" type="text" name="locations" id="location" aria-autocomplete="both" autoComplete="off" defaultValue />
                    </label>
                    <div className="searchbar__location-error hide">Please set location</div>
                    <label className="input-placeholder-group searchbar__checkin">
                      <span className="input-placeholder-label screen-reader-only">Check In</span>
                      <input type="text" readOnly="readonly" onfocus="this.blur()" id="checkin" className="checkin text-truncate input-large input-contrast ui-datepicker-target" placeholder="Check In" />
                      <input type="hidden" name="checkin" />
                    </label>
                    <label className="input-placeholder-group searchbar__checkout">
                      <span className="input-placeholder-label screen-reader-only">Check Out</span>
                      <input type="text" id="checkout" onfocus="this.blur()" readOnly="readonly" className="checkout input-large text-truncate input-contrast ui-datepicker-target" placeholder="Check Out" />
                      <input type="hidden" name="checkout" />
                    </label>
                    <label className="searchbar__guests">
                      <span className="screen-reader-only">Number of guests</span>
                      <div className="select select-large">
                        <select id="guests" name="guests">
                          <option value={1}> 1 Guest </option>
                          <option value={2}> 2 Guests </option>
                          <option value={3}> 3 Guests </option>
                          <option value={4}> 4 Guests </option>
                          <option value={5}> 5 Guests </option>
                          <option value={6}> 6 Guests </option>
                          <option value={7}> 7 Guests </option>
                          <option value={8}> 8 Guests </option>
                          <option value={9}> 9 Guests </option>
                          <option value={10}> 10 Guests </option>
                          <option value={11}> 11 Guests </option>
                          <option value={12}> 12 Guests </option>
                          <option value={13}> 13 Guests </option>
                          <option value={14}> 14 Guests </option>
                          <option value={15}> 15 Guests </option>
                          <option value={16}> 16 Guests </option>
                          <option value={17}> 17 Guests </option>
                          <option value={18}> 18 Guests </option>
                          <option value={19}> 19 Guests </option>
                          <option value={20}> 20 Guests </option>
                          <option value={21}> 21 Guests </option>
                          <option value={22}> 22 Guests </option>
                          <option value={23}> 23 Guests </option>
                          <option value={24}> 24 Guests </option>
                          <option value={25}> 25 Guests </option>
                          <option value={26}> 26 Guests </option>
                          <option value={27}> 27 Guests </option>
                          <option value={28}> 28 Guests </option>
                          <option value={29}> 29 Guests </option>
                          <option value={30}> 30+ Guests </option>
                        </select>
                      </div>
                    </label>
                    <div id="autocomplete-menu-sbea76915" aria-expanded="false" className="menu hide" aria-role="listbox">
                      <div className="menu-section">
                      </div>
                    </div>
                  </div>
                  <input type="hidden" name="source" defaultValue="bb" />
                  <button id="submit_location" type="submit" className="searchbar__submit btn btn-primary btn-large">Search</button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom mask style 4 */}
      <div className=" kl-bottommask kl-bottommask--mask4">
        {/* <svg width="5000px" height="27px" className="svgmask  " viewBox="0 0 5000 27" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
          <defs>
            <filter x="-50%" y="-50%" width="200%" height="200%" filterUnits="objectBoundingBox" id="filter-mask4">
              <feOffset dx={0} dy={2} in="SourceAlpha" result="shadowOffsetInner1" />
              <feGaussianBlur stdDeviation="1.5" in="shadowOffsetInner1" result="shadowBlurInner1" />
              <feComposite in="shadowBlurInner1" in2="SourceAlpha" operator="arithmetic" k2={-1} k3={1} result="shadowInnerInner1" />
              <feColorMatrix values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.35 0" in="shadowInnerInner1" type="matrix" result="shadowMatrixInner1" />
              <feMerge>
                <feMergeNode in="SourceGraphic" />
                <feMergeNode in="shadowMatrixInner1" />
              </feMerge>
            </filter>
          </defs>
          <path d="M3.63975516e-12,-0.007 L2418,-0.007 L2434,-0.007 C2434,-0.007 2441.89,0.742 2448,2.976 C2454.11,5.21 2479,15 2479,15 L2492,21 C2492,21 2495.121,23.038 2500,23 C2505.267,23.03 2508,21 2508,21 L2521,15 C2521,15 2545.89,5.21 2552,2.976 C2558.11,0.742 2566,-0.007 2566,-0.007 L2582,-0.007 L5000,-0.007 L5000,27 L2500,27 L3.63975516e-12,27 L3.63975516e-12,-0.007 Z" className="bmask-bgfill" filter="url(#filter-mask4)" fill="#fbfbfb" />
        </svg> */}
      </div>
      {/*/ Bottom mask style 4 */}
    </div>
        )
    }
}

export default Bannner;